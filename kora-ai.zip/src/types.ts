export type AgentStatus = 'idle' | 'running' | 'completed' | 'error';

export interface Agent {
  id: string;
  name: string;
  role: string;
  mission: string;
  personality: string;
  status: AgentStatus;
  progress: number;
  currentTask: string;
  color: string;
}

export interface WorkflowLog {
  id: string;
  timestamp: string;
  agentId?: string;
  agentName?: string;
  message: string;
  type: 'log' | 'info' | 'success' | 'error' | 'ai';
}

export interface GpuMetrics {
  utilization: number;
  memoryUsed: number;
  memoryTotal: number;
  tokensPerSec: number;
  latency: number;
  activeAgents: number;
}

export interface BusinessResult {
  brand_name: string;
  slogan: string;
  colors: string[];
  market_analysis: string;
  budget_estimate: string;
  marketing_plan: string;
  sales_scripts: string[];
}
