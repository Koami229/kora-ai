import { GoogleGenerativeAI } from "@google/generative-ai";
import { AGENTS } from "../constants";
import { Agent, WorkflowLog, BusinessResult } from "../types";

const ai = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");

export class AgentsService {
  private static instance: AgentsService;
  
  private constructor() {}

  public static getInstance(): AgentsService {
    if (!AgentsService.instance) {
      AgentsService.instance = new AgentsService();
    }
    return AgentsService.instance;
  }

  public async runWorkflow(
    objective: string, 
    onProgress: (agentId: string, progress: number, task: string) => void,
    onLog: (log: WorkflowLog) => void
  ): Promise<BusinessResult> {
    
    const model = ai.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      generationConfig: {
        responseMimeType: "application/json",
      }
    });

    onLog({
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString(),
      message: `Initialising KORA AI multi-agent orchestrator...`,
      type: 'info'
    });

    onLog({
      id: Math.random().toString(),
      timestamp: new Date().toLocaleTimeString(),
      message: `AMD ROCm Detected: Optimizing concurrent workflows for MI300X...`,
      type: 'info'
    });

    // Step 1: Market Research
    onProgress('market', 10, 'Initializing market scan...');
    await new Promise(r => setTimeout(r, 800));
    onProgress('market', 30, 'Analyzing Cotonou demographic gap...');
    onLog({ id: 'l1', timestamp: new Date().toLocaleTimeString(), agentId: 'market', agentName: 'Market Agent', message: 'Scanning regional market data in Cotonou...', type: 'ai' });
    
    await new Promise(r => setTimeout(r, 1200));
    onProgress('market', 70, 'Identifying competitor price points...');
    onLog({ id: 'l2', timestamp: new Date().toLocaleTimeString(), agentId: 'market', agentName: 'Market Agent', message: 'Found high demand for organic skincare with 15% annual growth.', type: 'ai' });

    // Step 2: Branding (Simulate Hand-off)
    onLog({ id: 'l2.5', timestamp: new Date().toLocaleTimeString(), message: 'Market Agent -> Branding Agent: "Focus on organic aesthetics for Cotonou youth."', type: 'info' });
    onProgress('branding', 20, 'Designing luxury minimalist logo...');
    onLog({ id: 'l3', timestamp: new Date().toLocaleTimeString(), agentId: 'branding', agentName: 'Branding Agent', message: 'Drafting concepts for a luxury minimalist aesthetic...', type: 'ai' });
    
    await new Promise(r => setTimeout(r, 1000));
    onProgress('branding', 60, 'Selecting color palette...');

    // Step 3: Finance
    onLog({ id: 'l3.5', timestamp: new Date().toLocaleTimeString(), message: 'Branding Agent -> Finance Agent: "Requesting asset production budget estimates."', type: 'info' });
    onProgress('finance', 30, 'Loading cost database...');
    onLog({ id: 'l4', timestamp: new Date().toLocaleTimeString(), agentId: 'finance', agentName: 'Finance Agent', message: 'Optimizing $500 budget allocation for maximum inventory ROI.', type: 'ai' });

    // Actual AI Generation for the final result
    const prompt = `Objective: ${objective}
    You are an AI Business Orchestrator. Generate a complete business launch plan.
    Structure the result as a raw JSON object with these keys:
    - brand_name: string (short and catchy)
    - slogan: string (memorable)
    - colors: string[] (3 hex codes that match the brand vibe)
    - market_analysis: string (2-3 sentences about the opportunity)
    - budget_estimate: string (A structured breakdown of how to spend the budget)
    - marketing_plan: string (Step-by-step strategy for TikTok and Instagram)
    - sales_scripts: string[] (3 WhatsApp sales messages for local customers)`;

    try {
      const gResult = await model.generateContent(prompt);
      const text = gResult.response.text();
      
      onProgress('marketing', 100, 'Social campaign generated.');
      onProgress('sales', 100, 'Sales scripts ready.');
      onProgress('market', 100, 'Market research completed.');
      onProgress('branding', 100, 'Branding completed.');
      onProgress('finance', 100, 'Financial plan ready.');

      onLog({
        id: Math.random().toString(),
        timestamp: new Date().toLocaleTimeString(),
        message: `Workflow completed successfully via AMD Accelerated Inference.`,
        type: 'success'
      });

      return JSON.parse(text);
    } catch (err) {
      console.error("AI Generation Error:", err);
      throw err;
    }
  }
}
