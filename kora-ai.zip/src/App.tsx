import React, { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';

export default function App() {
  const [isLaunched, setIsLaunched] = useState(false);

  return (
    <div className="h-screen w-full">
      {!isLaunched ? (
        <LandingPage onLaunch={() => setIsLaunched(true)} />
      ) : (
        <Dashboard />
      )}
    </div>
  );
}
