import React, { useEffect, useRef } from 'react';
import { ScrollArea } from './ui/scroll-area';
import { WorkflowLog } from '../types';

interface TerminalProps {
  logs: WorkflowLog[];
}

export function Terminal({ logs }: TerminalProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-black rounded-xl border border-white/10 p-3 font-mono text-[10px] overflow-hidden">
      <div className="flex items-center gap-2 mb-3 border-b border-white/10 pb-2 shrink-0">
        <span className="text-[8px] text-white/40 uppercase font-bold tracking-widest">ORCHESTRATOR_LOGS</span>
        <div className="flex-1 h-px bg-white/10"></div>
        <div className="flex gap-1">
          <div className="w-1 h-1 rounded-full bg-white/20" />
          <div className="w-1 h-1 rounded-full bg-white/20" />
        </div>
      </div>
      
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="space-y-1.5 text-white/60 italic overflow-hidden">
          {logs.length === 0 && (
            <p className="text-white/20 animate-pulse">[INFO] Awaiting Agent workforce input...</p>
          )}
          {logs.map((log) => (
            <div key={log.id} className="animate-in fade-in slide-in-from-left-1 duration-300">
              <span className={`
                ${log.type === 'ai' ? 'text-blue-400' : 
                  log.type === 'info' ? 'text-indigo-400' : 
                  log.type === 'success' ? 'text-[#10B981]' : 
                  log.type === 'error' ? 'text-red-400' : 'text-slate-300'}
              `}>
                [{log.agentId ? log.agentId.toUpperCase() : 'SYSTEM'}] {log.message}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
