import React from 'react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { Bot, Cpu, Rocket, Sparkles, ArrowRight, Zap, Target, BarChart3, Globe, ShieldCheck } from 'lucide-react';
import { badgeVariants } from './ui/badge';
import { cn } from '../lib/utils';

export function LandingPage({ onLaunch }: { onLaunch: () => void }) {
  return (
    <div className="min-h-screen bg-background selection:bg-amd-orange/30">
      <div className="fixed inset-0 animated-grid pointer-events-none opacity-20" />
      
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 px-8 py-6 flex items-center justify-between backdrop-blur-md bg-background/50 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-amd-orange rounded-lg flex items-center justify-center">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-display font-bold tracking-tight">KORA AI</span>
        </div>
        
        <div className="hidden md:flex items-center gap-8">
          {['Features', 'Market', 'Agents', 'Pricing'].map(item => (
            <a key={item} href={`#${item.toLowerCase()}`} className="text-sm font-medium text-muted-foreground hover:text-white transition-colors uppercase tracking-widest">{item}</a>
          ))}
        </div>

        <Button onClick={onLaunch} variant="amd" className="rounded-full px-6 font-bold uppercase tracking-widest text-xs h-10">Launch App</Button>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-40 pb-20 px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className={cn(badgeVariants({ variant: "outline" }), "bg-surface/50 border-white/10 px-4 py-1.5")}>
              <Sparkles className="w-4 h-4 mr-2 text-amd-orange" />
              <span className="text-xs font-bold uppercase tracking-widest">Powered by AMD ROCm & vLLM</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-display font-bold leading-[0.9] tracking-tighter text-white">
              Launch and run your business with <span className="text-transparent bg-clip-text bg-gradient-to-r from-amd-orange to-neon-purple">AI agents.</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-xl leading-relaxed">
              Kora AI coordinates autonomous AI agents to help entrepreneurs build brands, create campaigns and launch businesses faster—accelerated by AMD Instinct GPUs.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <Button onClick={onLaunch} className="bg-white text-black hover:bg-slate-200 h-14 px-8 rounded-2xl text-lg font-bold group">
                Start Building <ArrowRight className="ml-2 w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="outline" className="h-14 px-8 rounded-2xl text-lg font-bold border-white/10 glass-card">
                Watch Demo
              </Button>
            </div>

            <div className="flex items-center gap-6 pt-4 grayscale opacity-50">
              <img src="https://upload.wikimedia.org/wikipedia/commons/7/7c/AMD_Logo.svg" alt="AMD" className="h-6" />
              <div className="h-4 w-[1px] bg-white/10" />
              <p className="text-xs font-mono uppercase tracking-widest">Optimized for Instinct MI300X</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="relative h-[600px] flex items-center justify-center p-8 lg:p-0"
          >
            {/* Visual Agent Network Simulation */}
            <div className="absolute inset-0 bg-gradient-to-r from-amd-orange/5 to-neon-purple/5 blur-3xl rounded-full" />
            <AgentNetworkVisual />
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 px-8 bg-surface/30">
        <div className="max-w-7xl mx-auto space-y-20">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-display font-bold text-white uppercase tracking-tighter">Engineered for the AI Workforce</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Our multi-agent architecture leverages specialized LLMs optimized for unique business domains.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Target, title: 'Market Intelligence', desc: 'Real-time analysis of regional opportunities and competitor gaps using accelerated inference.' },
              { icon: Zap, title: 'ROCm Acceleration', desc: 'Leverage AMD ROCm stack for low-latency, concurrent agent orchestration.' },
              { icon: BarChart3, title: 'Financial Modeling', desc: 'Predictive ROI calculations and automated budget allocation for startup ventures.' },
              { icon: Globe, title: 'Global Campaigns', desc: 'Generate multi-platform marketing assets optimized for viral distribution.' },
              { icon: ShieldCheck, title: 'Operational Security', desc: 'Enterprise-grade coordination with human-in-the-loop oversight.' },
              { icon: Bot, title: 'Autonomous Agents', desc: 'Task-specific AI personas with individual goals and collaborative missions.' },
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="p-8 rounded-3xl glass-card space-y-4 group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center group-hover:bg-amd-orange/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-white group-hover:text-amd-orange transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-32 px-8">
        <div className="max-w-5xl mx-auto p-16 rounded-[48px] bg-gradient-to-br from-white/10 to-transparent border border-white/5 text-center space-y-8 relative overflow-hidden">
          <div className="absolute inset-0 bg-amd-orange/5 blur-3xl -z-10" />
          <h2 className="text-5xl font-display font-bold text-white">The future of business is autonomous.</h2>
          <p className="text-xl text-muted-foreground max-w-xl mx-auto">Join thousands of entrepreneurs tokens/sec on AMD infrastructure.</p>
          <Button onClick={onLaunch} className="bg-amd-orange text-white h-16 px-12 rounded-3xl text-xl font-bold glow-amd">
            Launch Your Business Now
          </Button>
        </div>
      </section>
    </div>
  );
}

function AgentNetworkVisual() {
  const nodes = [
    { x: 0, y: 0, label: 'KORA AI', main: true },
    { x: -140, y: -140, label: 'Market' },
    { x: 140, y: -140, label: 'Branding' },
    { x: 140, y: 140, label: 'Finance' },
    { x: -140, y: 140, label: 'Marketing' },
    { x: -180, y: 0, label: 'Sales' },
  ];

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Central Node */}
      <motion.div
        animate={{ 
          scale: [1, 1.1, 1],
          boxShadow: ['0 0 20px rgba(255,107,0,0.2)', '0 0 50px rgba(255,107,0,0.5)', '0 0 20px rgba(255,107,0,0.2)']
        }}
        transition={{ duration: 3, repeat: Infinity }}
        className="z-10 w-24 h-24 bg-amd-orange rounded-full flex items-center justify-center border-4 border-white/20"
      >
        <Rocket className="w-10 h-10 text-white" />
      </motion.div>

      {/* Satellite Nodes */}
      {nodes.slice(1).map((node, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: i * 0.1 + 0.5 }}
          className="absolute"
          style={{ x: node.x, y: node.y }}
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 3 + i, repeat: Infinity, ease: 'easeInOut' }}
            className="flex flex-col items-center gap-2"
          >
            <div className="w-12 h-12 bg-surface border border-white/10 rounded-2xl flex items-center justify-center glass-card shadow-2xl">
              <Bot className="w-6 h-6 text-neon-purple" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground whitespace-nowrap bg-black/50 px-2 py-0.5 rounded backdrop-blur-md">{node.label}</span>
          </motion.div>
          
          {/* Connection Line */}
          <svg className="absolute top-1/2 left-1/2 -z-10 w-[400px] h-[400px] -translate-x-1/2 -translate-y-1/2 overflow-visible">
            <motion.line
              x1="200" y1="200"
              x2={200 + node.x} y2={200 + node.y}
              stroke="white"
              strokeWidth="1"
              strokeOpacity="0.1"
              strokeDasharray="4 4"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 1.5, delay: 0.5 }}
            />
          </svg>
        </motion.div>
      ))}
    </div>
  );
}
