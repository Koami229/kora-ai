import React, { useEffect, useState } from 'react';
import { GpuMetrics } from '../types';
import { motion } from 'motion/react';

export function GpuMetricsPanel() {
  const [metrics, setMetrics] = useState<GpuMetrics>({
    utilization: 0,
    memoryUsed: 0,
    memoryTotal: 192,
    tokensPerSec: 0,
    latency: 0,
    activeAgents: 0,
  });

  useEffect(() => {
    const eventSource = new EventSource('/api/metrics');
    
    eventSource.onmessage = (event) => {
      try {
        const newMetrics = JSON.parse(event.data);
        setMetrics(newMetrics);
      } catch (err) {
        console.error("Failed to parse GPU metrics:", err);
      }
    };

    eventSource.onerror = (err) => {
      // In development environments like AI Studio, 
      // EventSource might drop due to infrastructure proxying.
      // We just close and ignore as it will auto-reconnect or we can let it be.
      console.warn("GPU Metrics stream disconnected. Reconnecting...");
    };

    return () => eventSource.close();
  }, []);

  return (
    <div className="space-y-4">
      <div className="bg-white/5 rounded-xl p-3 border border-white/10">
        <div className="flex justify-between items-end mb-2">
          <span className="text-[10px] text-white/40 uppercase font-bold tracking-wider">GPU Utilization</span>
          <span className="text-sm font-mono font-bold text-[#FF6B00]">{metrics.utilization.toFixed(1)}%</span>
        </div>
        <div className="h-8 w-full flex items-end gap-[2px]">
          {[0.6, 0.8, 0.4, 0.9, 0.84, 0.7, 0.65, 0.5, 0.8, 0.95].map((h, i) => (
             <motion.div 
               key={i}
               initial={{ height: 0 }}
               animate={{ height: `${h * 100}%` }}
               transition={{ duration: 0.5, delay: i * 0.05 }}
               className={`bg-[#FF6B00] w-full rounded-t-sm ${h < 0.6 ? 'opacity-30' : h < 0.8 ? 'opacity-50' : 'opacity-100'}`}
             />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white/5 rounded-xl p-3 border border-white/10 group hover:border-[#FF6B00]/30 transition-colors">
          <p className="text-[10px] text-white/40 uppercase mb-1 font-bold">Thruput</p>
          <p className="text-sm font-mono font-bold text-white whitespace-nowrap">
            {metrics.tokensPerSec.toFixed(0)} <span className="text-[10px] opacity-40 font-normal">tok/s</span>
          </p>
        </div>
        <div className="bg-white/5 rounded-xl p-3 border border-white/10 group hover:border-[#7C3AED]/30 transition-colors">
          <p className="text-[10px] text-white/40 uppercase mb-1 font-bold">VRAM</p>
          <p className="text-sm font-mono font-bold text-white">
            {metrics.memoryUsed.toFixed(0)} <span className="text-[10px] opacity-40 font-normal">GB</span>
          </p>
        </div>
        <div className="bg-white/5 rounded-xl p-3 border border-white/10">
          <p className="text-[10px] text-white/40 uppercase mb-1 font-bold">Latency</p>
          <p className="text-sm font-mono font-bold text-[#10B981]">
            {metrics.latency.toFixed(0)} <span className="text-[10px] opacity-40 font-normal">ms</span>
          </p>
        </div>
        <div className="bg-white/5 rounded-xl p-3 border border-white/10">
          <p className="text-[10px] text-white/40 uppercase mb-1 font-bold">Active</p>
          <p className="text-sm font-mono font-bold text-[#7C3AED]">
            {metrics.activeAgents} <span className="text-[10px] opacity-40 font-normal">Agents</span>
          </p>
        </div>
      </div>
    </div>
  );
}
