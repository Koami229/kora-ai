import React, { useState, useEffect } from 'react';
import { Sidebar } from './Sidebar';
import { GpuMetricsPanel } from './GpuMetricsPanel';
import { AgentCard } from './AgentCard';
import { Terminal } from './Terminal';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Separator } from './ui/separator';
import { Card } from './ui/card';
import { AGENTS } from '../constants';
import { Agent, WorkflowLog, BusinessResult } from '../types';
import { AgentsService } from '../services/agentsService';
import { Rocket, Sparkles, Download, Share2, ArrowRight, LayoutGrid, FileText, Settings, History } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Dashboard() {
  const [objective, setObjective] = useState('Launch a cosmetic business in Cotonou with $500.');
  const [agents, setAgents] = useState<Agent[]>(AGENTS);
  const [logs, setLogs] = useState<WorkflowLog[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<BusinessResult | null>(null);

  const agentsService = AgentsService.getInstance();

  const handleRunWorkflow = async () => {
    if (!objective || isProcessing) return;
    
    setIsProcessing(true);
    setResult(null);
    setLogs([]);
    setAgents(AGENTS.map(a => ({ ...a, status: 'idle', progress: 0, currentTask: 'Awaiting instructions...' })));

    try {
      const businessResult = await agentsService.runWorkflow(
        objective,
        (agentId, progress, task) => {
          setAgents(prev => prev.map(a => 
            a.id === agentId ? { ...a, status: progress === 100 ? 'completed' : 'running', progress, currentTask: task } : a
          ));
        },
        (log) => setLogs(prev => [...prev, log])
      );
      
      setResult(businessResult);
    } catch (error) {
      console.error('Workflow failed:', error);
      setLogs(prev => [...prev, { id: 'err', timestamp: new Date().toLocaleTimeString(), message: 'Critical Error: Workflow interrupted.', type: 'error' }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#070B14] text-white overflow-hidden">
      {/* TOP NAV BAR */}
      <header className="h-14 border-b border-white/10 flex items-center justify-between px-6 bg-[#070B14]/80 backdrop-blur-md shrink-0 z-30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-[#FF6B00] to-[#7C3AED] rounded-lg flex items-center justify-center font-bold text-xl tracking-tighter">K</div>
          <h1 className="text-lg font-semibold tracking-tight">KORA <span className="text-[#FF6B00]">AI</span> <span className="text-xs font-mono text-white/40 ml-2 uppercase tracking-widest">v0.8.2-alpha</span></h1>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex gap-4 text-xs font-medium text-white/60">
            <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[#10B981]"></span> AMD INSTINCT™ MI300X ACTIVE</span>
            <span className="flex items-center gap-1.5 font-mono">LATENCY: 117MS</span>
          </div>
          <div className="w-px h-4 bg-white/20"></div>
          <button className="px-4 py-1.5 bg-white/10 hover:bg-white/20 rounded text-xs transition-all border border-white/10">DASHBOARD</button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden relative">
        <div className="absolute inset-0 animated-grid pointer-events-none opacity-10" />
        <Sidebar />
        
        {/* MAIN WORKSPACE */}
        <main className="flex-1 flex flex-col p-6 overflow-hidden gap-6 z-10">
          <section className="flex-1 flex flex-col gap-6 overflow-y-auto custom-scrollbar">
            {/* Input Area */}
            <div className="bg-[#111827] rounded-2xl border border-white/10 p-6 relative overflow-hidden flex flex-col shrink-0">
               <div className="absolute top-0 right-0 w-64 h-64 bg-[#7C3AED]/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
               <div className="flex justify-between items-start mb-6">
                 <div>
                   <h2 className="text-2xl font-bold tracking-tight mb-1">Multi-Agent Orchestration</h2>
                   <p className="text-white/40 text-sm italic">Concurrent business generation via ROCm...</p>
                 </div>
                 <Button 
                   onClick={handleRunWorkflow}
                   disabled={isProcessing}
                   className="bg-[#FF6B00] hover:bg-[#FF6B00]/90 text-white font-bold h-10 px-6 rounded-xl transition-all active:scale-95 shadow-xl shadow-orange-500/10"
                 >
                   {isProcessing ? 'Executing Workflow...' : 'Run Autonomous Launch'}
                 </Button>
               </div>
               
               <div className="relative group">
                 <Input 
                   value={objective}
                   onChange={(e) => setObjective(e.target.value)}
                   className="bg-black/20 border-white/10 h-12 text-lg focus:border-[#FF6B00]/50 transition-all rounded-xl"
                   placeholder="Enter business directive..."
                   disabled={isProcessing}
                 />
                 <Sparkles className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#FF6B00] animate-pulse" />
               </div>
            </div>

            {/* Agent Statuses */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 shrink-0">
              {agents.map(agent => (
                <AgentCard key={agent.id} agent={agent} />
              ))}
            </div>

            {/* Results Reveal */}
            <AnimatePresence>
              {result && (
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pb-8"
                >
                  <Card className="bg-[#111827] border-white/10 p-5 col-span-full mb-2">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold">Business Assets Compiled</h3>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="h-8 border-white/10 text-xs text-white/60">JSON Export</Button>
                        <Button className="h-8 bg-[#FF6B00] text-white text-xs font-bold px-4">Download All</Button>
                      </div>
                    </div>
                  </Card>

                  <div className="p-4 rounded-xl bg-white/5 border border-[#FF6B00]/20 flex flex-col justify-between h-48">
                    <div>
                      <span className="text-[10px] uppercase tracking-widest text-[#FF6B00] font-bold mb-2 block">Branding Identity</span>
                      <h4 className="text-xl font-bold mb-1">{result.brand_name}</h4>
                      <p className="text-xs text-white/60 leading-tight italic">"{result.slogan}"</p>
                    </div>
                    <div className="flex gap-2 mt-4">
                      {result.colors.map(c => <div key={c} className="w-6 h-6 rounded-full border border-white/10" style={{ backgroundColor: c }} />)}
                    </div>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 h-48 overflow-hidden flex flex-col">
                    <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-2 block">Market Strategy</span>
                    <p className="text-xs text-white/60 leading-relaxed overflow-y-auto custom-scrollbar flex-1">{result.market_analysis}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-[#FF6B00] flex flex-col justify-between h-48 text-black">
                     <div>
                       <span className="text-[10px] uppercase tracking-widest font-black mb-2 block text-black/60">Financial Outlook</span>
                       <h4 className="text-sm font-bold truncate">Launch Budget: $500</h4>
                     </div>
                     <p className="text-[11px] font-medium leading-tight text-black/80">{result.budget_estimate}</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        </main>

        {/* RIGHT PANEL: GPU MONITOR & LOGS */}
        <aside className="w-72 border-l border-white/10 bg-[#0b101d] flex flex-col p-4 shrink-0 overflow-hidden z-20">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-2 h-2 rounded-full bg-[#FF6B00] shadow-[0_0_8px_rgba(255,107,0,0.6)] animate-pulse"></div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-white/80">Hardware Node: AMD-01</h2>
          </div>

          <div className="space-y-4 mb-6">
            <GpuMetricsPanel />
          </div>

          <div className="flex-1 min-h-0 flex flex-col">
            <Terminal logs={logs} />
          </div>
        </aside>
      </div>

      {/* STATUS FOOTER */}
      <footer className="h-8 border-t border-white/10 bg-[#070B14] px-6 flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-4">
          <span className="text-[9px] text-white/40 uppercase tracking-tighter">AMD ROCm™ Stack: 6.2.0</span>
          <span className="text-[9px] text-white/40 uppercase tracking-tighter font-mono">vLLM Inference: ACTIVE</span>
        </div>
        <div className="text-[9px] text-white/20 uppercase tracking-widest font-mono">Session: KORA-AMD-PROD-B52</div>
      </footer>
    </div>
  );
}
