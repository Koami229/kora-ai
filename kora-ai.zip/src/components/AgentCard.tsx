import React from 'react';
import { Agent } from '../types';
import { motion } from 'motion/react';

interface AgentCardProps {
  agent: Agent;
}

export function AgentCard({ agent }: AgentCardProps) {
  const isRunning = agent.status === 'running';
  const isCompleted = agent.status === 'completed';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="h-full"
    >
      <div className={`p-4 rounded-xl bg-white/5 border flex flex-col justify-between h-full transition-all duration-500 ${isRunning ? 'border-[#7C3AED]/30 shadow-[0_0_20px_rgba(124,58,237,0.05)]' : isCompleted ? 'border-[#10B981]/20' : 'border-white/10'}`}>
        <div>
          <div className="flex justify-between items-center mb-3">
            <span className="text-[10px] uppercase tracking-widest font-bold" style={{ color: agent.color }}>
              {agent.id}
            </span>
            <span className="text-[10px] font-mono text-white/40">v0.8.2</span>
          </div>
          <h4 className="text-sm font-semibold mb-1">{agent.name}</h4>
          <p className="text-[10px] text-white/60 leading-tight line-clamp-2">{agent.currentTask}</p>
        </div>
        
        <div className="mt-4">
          <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${agent.progress}%` }}
              className={`h-full transition-all duration-1000 ${isRunning ? 'bg-[#7C3AED] animate-pulse' : isCompleted ? 'bg-[#10B981]' : 'bg-white/20'}`}
            />
          </div>
          <p className={`text-[10px] mt-2 font-mono uppercase tracking-wider ${isRunning ? 'text-[#7C3AED] animate-pulse' : isCompleted ? 'text-[#10B981]' : 'text-white/40'}`}>
            {isRunning ? 'Processing...' : isCompleted ? 'Completed' : 'Awaiting...'}
          </p>
        </div>
      </div>
    </motion.div>
  );
}
