import React from 'react';
import { LayoutGrid, Bot, Activity, Layers, Settings, LogOut, Cpu, Users, Workflow } from 'lucide-react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';

export function Sidebar() {
  const menuItems = [
    { icon: LayoutGrid, label: 'Workflow Center', active: true },
    { icon: Users, label: 'Agent Workforce' },
    { icon: Workflow, label: 'Automations' },
    { icon: Layers, label: 'Asset Library' },
    { icon: Activity, label: 'Analytics' },
  ];

  return (
    <aside className="w-64 h-full border-r border-white/10 bg-[#0b101d] flex flex-col shrink-0 z-20">
      <div className="p-6 pb-4">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-8 h-8 bg-gradient-to-br from-[#FF6B00] to-[#7C3AED] rounded-lg flex items-center justify-center font-bold text-xl tracking-tighter shadow-lg shadow-orange-500/10">
            K
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-white leading-none">KORA <span className="text-[#FF6B00]">AI</span></h1>
            <p className="text-[10px] text-white/40 uppercase tracking-widest font-mono mt-1">v0.8.2-alpha</p>
          </div>
        </div>

        <div className="mb-8">
          <p className="text-[10px] text-white/40 uppercase tracking-widest mb-4 font-bold">Core Agent Cluster</p>
          <nav className="space-y-1">
            {menuItems.map((item) => (
              <div
                key={item.label}
                className={`flex items-center justify-between p-2.5 rounded cursor-pointer transition-all duration-300 group ${item.active ? 'bg-white/5 border-l-2 border-[#FF6B00]' : 'hover:bg-white/5'}`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                  <span className={`text-sm ${item.active ? 'text-white' : 'text-white/70 group-hover:text-white'}`}>{item.label}</span>
                </div>
                <span className={`flex h-2 w-2 rounded-full ${item.active ? 'bg-[#10B981] shadow-[0_0_8px_rgba(16,185,129,0.6)]' : 'bg-white/20'}`}></span>
              </div>
            ))}
          </nav>
        </div>
      </div>

      <div className="mt-auto border-t border-white/10 p-6">
        <div className="p-4 bg-[#111827] rounded-xl border border-white/5 mb-6">
          <p className="text-[10px] text-white/40 uppercase tracking-widest mb-2 font-bold">Project Context</p>
          <h3 className="text-xs font-medium text-[#FF6B00] mb-1 italic leading-relaxed">"Launch a cosmetic business in Cotonou with $500"</h3>
        </div>

        <div className="flex items-center gap-3 p-2 group cursor-pointer hover:bg-white/5 rounded-xl transition-colors">
          <Avatar className="h-8 w-8 border border-white/10">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" />
            <AvatarFallback>EK</AvatarFallback>
          </Avatar>
          <div className="flex-1 overflow-hidden">
            <p className="text-xs font-bold truncate text-white">John Entrepreneur</p>
            <p className="text-[9px] text-white/40 uppercase tracking-wider font-medium">Founder Tier</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
