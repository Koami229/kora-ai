import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", engine: "AMD ROCm Optimized", gpu: "MI300X Accelerator" });
  });

  // Mock GPU Metrics Stream (SSE)
  app.get("/api/metrics", (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const sendMetrics = () => {
      const metrics = {
        utilization: 75 + Math.random() * 15,
        memoryUsed: 156 + Math.random() * 10,
        memoryTotal: 192,
        tokensPerSec: 140 + Math.random() * 30,
        latency: 110 + Math.random() * 20,
        activeAgents: Math.floor(Math.random() * 6),
        timestamp: new Date().toISOString()
      };
      res.write(`data: ${JSON.stringify(metrics)}\n\n`);
    };

    const interval = setInterval(sendMetrics, 2000);
    req.on('close', () => clearInterval(interval));
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`KORA AI Server running on http://localhost:${PORT}`);
    console.log(`AMD ROCm Accelerator: Active`);
  });
}

startServer();
